package provaN1;

public class Location {
    private int id;

    public static void main(String[] args) {
        System.out.println();
    }

    public Location(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
