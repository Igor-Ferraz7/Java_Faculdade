package provaN1;

public class Location {
    private int id, qtd_quartos, qtd_banheiros, quadra, lote, numero, qtd_max_hospedes, qtd_camas, qtd_recomendacoes;
    private String tipo_local, ponto_referencia, bairro, rua;

    public static void main(String[] args) {
        System.out.println();
    }
/*
    public Location(int id, int qtd_quartos, int qtd_banheiros, int bairro, int rua, int numero, int qtd_max_hospedes,
                    int qtd_camas, int qtd_recomendacoes, String tipo_local, String ponto_referencia, String bairro, String rua) {

    }
*/
}
