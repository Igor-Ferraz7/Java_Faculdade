package provaN1;

public class Reserva_Conflito {
    int id_reserva, id_cliente, id_local;
    String data_chekIn, data_chekOut;

    public Reserva_Conflito(int id_reserva, int id_cliente, int id_local, String data_chekIn, String data_chekOut) {
        this.id_reserva = id_reserva;
        this.id_cliente = id_cliente;
        this.id_local = id_local;
        this.data_chekIn = data_chekIn;
        this.data_chekOut = data_chekOut;
    }
}
