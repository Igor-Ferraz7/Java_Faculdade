package provaN1;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class File_reader {
    private  static File file_client = new File("C:\\Users\\igors\\OneDrive\\Documentos\\Estudos\\Java\\Java_Faculdade\\Quarto_Periodo\\src\\provaN1\\clients.csv");
    private static File file_location = new File("C:\\Users\\igors\\OneDrive\\Documentos\\Estudos\\Java\\Java_Faculdade\\Quarto_Periodo\\src\\provaN1\\prova.java");
    private static File file_reseva_conflito = new File("C:\\Users\\igors\\OneDrive\\Documentos\\Estudos\\Java\\Java_Faculdade\\Quarto_Periodo\\src\\provaN1\\reservas_conflitos.csv");

    public static void main(String[] args) {
        List<Cliente> c1 = client_reader();

        for (int i = 0; i < c1.size(); i++) {

        }
    }

    public static List<Cliente> client_reader() {
        List<Cliente> clientes = new ArrayList<Cliente>();
        int count = 0;

        try (Scanner fileScanner = new Scanner(file_client)) {
            while (fileScanner.hasNextLine()) {
                String full_line = fileScanner.nextLine();

                if (count != 0) {
                    String id = full_line.split(";")[0];
                    String nome = full_line.split(";")[1];
                    String endereco = full_line.split(";")[2];
                    String idade = full_line.split(";")[3];
                    String sexo = full_line.split(";")[4];
                    String preferencia_estadia = full_line.split(";")[5];

                    clientes.add(new Cliente(Integer.parseInt(id), nome, endereco, Integer.parseInt(idade), sexo, preferencia_estadia));
                }

                count++;

            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("N�o foi poss�vel ler o arquivo 'clients.cs'");
        }

        return clientes;
    }

}
