package provaN1;

public class Cliente {
    private int id, idade;
    private String nome, endereco, sexo, preferencia_estadia;

    public Cliente(int id, String nome, String endereco, int idade, String sexo, String preferencia_estadia) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.sexo = sexo;
        this.preferencia_estadia = preferencia_estadia;
    }

}
