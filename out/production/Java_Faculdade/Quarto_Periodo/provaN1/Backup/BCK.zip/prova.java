package provaN1;

/*
Desenvolva as classes relacionadas aos arquivos em anexo, importe os dados para
listas correspondentes a cada classe.
Apresente uma lista com o nome do cliente, o ID da reserva, a data de check-in a data de check-out,
o status da reserva (reservado ou n�o reservado) e o motivo caso n�o reservado;
 */

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class prova {

    List<Cliente> clientes = new ArrayList<Cliente>();
    List<Location> locations = new ArrayList<Location>();
    List<Reserva_Conflito> reservaConflitos = new ArrayList<Reserva_Conflito>();


    public static void main(String[] args) {
        String a = "1";
        int b = Integer.parseInt(a);

        System.out.println(b);

    }


}
