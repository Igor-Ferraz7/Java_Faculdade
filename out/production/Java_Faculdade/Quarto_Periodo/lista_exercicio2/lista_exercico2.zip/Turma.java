package lista_exercicio2;

public class Turma {
    private Materia materia;
    private String[] alunos;
    private String codigo;

    public void adicionar_aluno(Aluno aluno) {}
    public void listar_alunos() {}

}
