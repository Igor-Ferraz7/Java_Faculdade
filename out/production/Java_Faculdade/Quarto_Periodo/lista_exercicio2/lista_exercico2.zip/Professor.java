package lista_exercicio2;

public class Professor extends Pessoa{
    private String[] cursos;

    public void adicionar_curso(String curso) {}

    public void listar_cursos(String[] cursos) {}
}
