package lista_exercicio2;

public class Pessoa {
    private String nome;
    private int idade;
    private String id;

}
