package lista_exercicio2;

public class Materia {
    private String nome;
    private int codigo;
    private Professor professor;

}
