package lista_exercicio2;

public class Escola {
    private String nome;
    private String[] curso;
    private String[] turmas;

    public void adicionar_curso() {}

    public void adicionar_turma() {}

    public void listar_curso() {}

    public void listar_turmas() {}

}
