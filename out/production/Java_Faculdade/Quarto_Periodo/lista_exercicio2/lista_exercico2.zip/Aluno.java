package lista_exercicio2;

import java.util.Dictionary;
import java.util.Hashtable;

public class Aluno {
    private Dictionary notas = new Hashtable();
    private float media;

    public void adicionar_nota(String curso, float nota) {}

    public float obter_media() {
        return this.media;
    }

}
