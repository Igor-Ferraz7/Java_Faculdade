package lista_ex2;

public class ex13 {
    public static void main(String[] args) {
        System.out.println(module_number(-11));
    }

    public static int module_number(int num) {
        return num * -1;
    }

}
