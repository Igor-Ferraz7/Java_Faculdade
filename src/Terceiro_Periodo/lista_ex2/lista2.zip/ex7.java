package lista_ex2;

public class ex7 {
    public static void main(String[] args) {
        square(7);
    }

    public static void square(int num) {
        System.out.printf("%d x %d = %d\n", num, num, num*num);
    }

}
