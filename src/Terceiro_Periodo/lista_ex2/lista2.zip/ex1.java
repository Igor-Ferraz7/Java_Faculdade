package lista_ex2;

public class ex1 {
    public static void main(String[] args) {
        one_to_10();
    }
    public static void one_to_10() {
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }
    }
}