package lista_ex2;

public class ex2 {
    public static void main(String[] args) {
        pairs_to_10();
    }

    public static void pairs_to_10() {
        for (int i = 0; i <= 100; i+=2) {
            System.out.println(i);
        }
    }
}
