package lista_ex2;

public class ex3 {
    public static void main(String[] args) {
        tables_book();
    }

    public static void tables_book() {
        for (int i = 1; i <= 10; i++) {
            System.out.printf("5 x %d = %d\n", i, i*5);
        }
    }

}
