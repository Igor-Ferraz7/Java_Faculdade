package lista_ex2;

public class ex8 {
    public static void main(String[] args) {
        String msg = Hello_World();
        System.out.println(msg);
    }

    public static String Hello_World() {
        return "Hello World!";
    }

}
