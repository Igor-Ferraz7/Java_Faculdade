package lista_ex2;

public class ex11 {
    public static void main(String[] args) {
        System.out.println(double_num(110));
    }

    public static int double_num(int num) {
        return num * 2;
    }

}
