package exercicios_lista23.ex1;

public class Person {
    private String name;
    private int anoNasc;

    public String getName() {
        return name;
    }

    public int getAnoNasc() {
        return anoNasc;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAnoNasc(int anoNasc) {
        this.anoNasc = anoNasc;
    }
}
