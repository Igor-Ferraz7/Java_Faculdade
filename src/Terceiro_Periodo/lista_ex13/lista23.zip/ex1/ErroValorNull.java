package exercicios_lista23.ex1;

public class ErroValorNull extends Exception{
    public ErroValorNull(String msg) {
        super(msg);
    }
}
//NullPointerException