package exercicios_lista23.ex5;


public class InvalidTemperatureException extends Exception{
    public InvalidTemperatureException(String msg) {
        super(msg);
    }
}
