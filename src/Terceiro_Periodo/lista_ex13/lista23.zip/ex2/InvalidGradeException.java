package exercicios_lista23.ex2;

public class InvalidGradeException extends Exception{
    public InvalidGradeException(String msg) {
        super(msg);
    }
}
