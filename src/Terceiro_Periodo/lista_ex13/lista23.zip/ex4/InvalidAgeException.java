package exercicios_lista23.ex4;

public class InvalidAgeException extends Exception{
    public InvalidAgeException(String msg) {
        super(msg);
    }
}