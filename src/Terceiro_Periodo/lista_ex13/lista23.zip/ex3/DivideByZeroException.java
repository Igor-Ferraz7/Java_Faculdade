package exercicios_lista23.ex3;

public class DivideByZeroException extends Exception{
    public DivideByZeroException(String msg) {
        super(msg);
    }
}