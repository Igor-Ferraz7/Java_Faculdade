package lista_ex3;

import java.util.Arrays;

public class ex5 {
    public static void main(String[] args) {
        int[] vector = new int[]{1, 2, 3, 4, 5, 6, 7};
        imprimirVetor(vector);
    }

    public static int[] imprimirVetor(int[] vector) {
        System.out.println(Arrays.toString(vector));
        return vector;
    }
}
