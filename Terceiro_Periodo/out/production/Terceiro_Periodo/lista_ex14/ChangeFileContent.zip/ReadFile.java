package exercicios_lista24;

import java.io.File;
import java.io.FileReader;

public class ReadFile {

    public static void main(String[] args) {
        System.out.println("Main sendo excecutado.");
        ReadFile.readF("mytext.txt");
    }

    public static void readF(String fileName) {
        String fileDirectory = "C:\\Users\\igors\\IdeaProjects\\Faculdade\\src\\exercicios_lista24\\";
        fileName = fileDirectory + fileName;
        File file = new File(fileName);


        try (FileReader fileReader = new FileReader(file)){
            int charCode;

            System.out.println("----------------------------------------");
            System.out.println(">> Conte�do do arquivo:");

            while ((charCode = fileReader.read()) != -1) {
                char character = (char) charCode;
                System.out.print(character);
            }

            System.out.println("----------------------------------------");
        } catch (Exception e) {
            System.out.println("Falha ao ler o arquivo.");
            System.out.println(e.getMessage());
        }

    }
}
