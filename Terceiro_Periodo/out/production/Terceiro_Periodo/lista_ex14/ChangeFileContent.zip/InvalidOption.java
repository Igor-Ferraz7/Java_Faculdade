package exercicios_lista24;

public class InvalidOption extends Exception{
    public InvalidOption(String msg) {
        super(msg);
    }
}