package lista_ex5;

/*
Criar uma função recursiva que calcule o n-ésimo número da sequência de Fibonacci.
 */

public class ex4 {
    public static void main(String[] args) {
        System.out.println(NumberFibonacci(6));
    }

    public static int NumberFibonacci(int n){
        // 0  1  1  2  3  5
        // 1  2  3  4  5  6 <- n

        if (n > 0) {
            return NumberFibonacci(n-1) + NumberFibonacci(n-2);
        /*
           n=1    NumberFibonacci(0) -> 0  +  1 <- NumberFibonacci(-1) | 0  +  1 = 1
           n=2    NumberFibonacci(1) -> 1  +  0 <- NumberFibonacci(0)  | 1  +  0 = 1
           n=3    NumberFibonacci(2) -> 1  +  1 <- NumberFibonacci(2)  | 1  +  1 = 2
           n=4    NumberFibonacci(3) -> 2  +  1 <- NumberFibonacci(4)  | 2  +  1 = 3
           n=5    NumberFibonacci(4) -> 3  +  2 <- NumberFibonacci(6)  | 3  +  2 = 5
                                         [...]
        */
        }
        return -n;
    }
}
