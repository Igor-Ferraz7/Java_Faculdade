package exercicios_lista26.ex4;

public class LinhaInvalidaException extends Exception{
    public LinhaInvalidaException(String msg) {
        super(msg);
    }
}
